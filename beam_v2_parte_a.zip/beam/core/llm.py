"""
core/llm.py — Capa de generación de texto.

Aísla toda la interacción con el proveedor de IA (hoy DeepSeek, vía SDK
compatible con OpenAI) detrás de funciones simples. El resto de la app
nunca importa `openai` directamente: solo llama a estas funciones. Esto
es lo que hace trivial, en la Parte B, sustituir esta capa por un
registro multi-proveedor (Claude, GPT, Gemini, OpenRouter, local) sin
tocar ui/editor.py ni app.py.
"""

import re
from typing import Iterator

from openai import OpenAI

from core.config import (
    DEEPSEEK_BASE_URL,
    MODELO_DEFECTO,
    SYSTEM_PROMPT_BASE,
    TERMINOLOGIA_CORRECTA,
    ESTILOS_REDACCION,
    SECCIONES,
)


# ──────────────────────────────────────────────────────────────────────────
# CLIENTE
# ──────────────────────────────────────────────────────────────────────────

def obtener_cliente(api_key: str) -> OpenAI:
    return OpenAI(api_key=api_key, base_url=DEEPSEEK_BASE_URL)


def aplicar_terminologia(texto: str) -> str:
    for incorrecto, correcto in TERMINOLOGIA_CORRECTA.items():
        texto = texto.replace(incorrecto, correcto)
        texto = texto.replace(incorrecto.capitalize(), correcto.capitalize())
    return texto


# ──────────────────────────────────────────────────────────────────────────
# GENERACIÓN INICIAL DEL INFORME (dictado → informe completo, en streaming)
# ──────────────────────────────────────────────────────────────────────────

def generar_informe_stream(
    api_key: str,
    dictado: str,
    contexto_extra: str = "",
    modelo: str = MODELO_DEFECTO,
) -> Iterator[str]:
    """Genera el informe completo a partir del dictado, en streaming.

    `contexto_extra` permite inyectar, sin tocar el prompt base, cosas como
    una plantilla de estilo del radiólogo o un estudio previo para comparar
    (piezas que se agregan en la Parte B sin romper esta función).
    """
    cliente = obtener_cliente(api_key)
    system_prompt = SYSTEM_PROMPT_BASE
    if contexto_extra:
        system_prompt += f"\n\n{contexto_extra}"

    stream = cliente.chat.completions.create(
        model=modelo,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": dictado},
        ],
        temperature=0.2,
        stream=True,
    )
    for fragmento in stream:
        delta = fragmento.choices[0].delta
        texto = getattr(delta, "content", None) or ""
        if texto:
            yield texto


# ──────────────────────────────────────────────────────────────────────────
# PARSEO / RECONSTRUCCIÓN DEL INFORME COMO OBJETO ESTRUCTURADO
# Esto es lo que convierte "el último mensaje del chat" en un documento
# real con tres campos independientes y editables.
# ──────────────────────────────────────────────────────────────────────────

_PATRON_ENCABEZADO = re.compile(
    r"(?im)^\s*(T[ÉE]CNICA|HALLAZGOS|CONCLUSI[ÓO]N)\s*:?\s*$", re.MULTILINE
)


def parsear_informe(texto: str) -> dict:
    """Convierte el texto plano generado por el modelo en {tecnica, hallazgos, conclusion}."""
    partes = {}
    coincidencias = list(_PATRON_ENCABEZADO.finditer(texto))
    for i, m in enumerate(coincidencias):
        clave = m.group(1).upper().replace("TECNICA", "TÉCNICA").replace("CONCLUSION", "CONCLUSIÓN")
        inicio = m.end()
        fin = coincidencias[i + 1].start() if i + 1 < len(coincidencias) else len(texto)
        partes[clave] = texto[inicio:fin].strip()

    return {
        "tecnica": aplicar_terminologia(partes.get("TÉCNICA", "")),
        "hallazgos": aplicar_terminologia(partes.get("HALLAZGOS", "")),
        "conclusion": aplicar_terminologia(partes.get("CONCLUSIÓN", "")),
    }


def reconstruir_informe(informe: dict) -> str:
    """Convierte {tecnica, hallazgos, conclusion} de vuelta a texto plano (para copiar/exportar)."""
    return (
        f"TÉCNICA\n{informe.get('tecnica', '').strip()}\n\n"
        f"HALLAZGOS\n{informe.get('hallazgos', '').strip()}\n\n"
        f"CONCLUSIÓN\n{informe.get('conclusion', '').strip()}"
    )


def informe_vacio(informe: dict) -> bool:
    return not any((informe.get("tecnica"), informe.get("hallazgos"), informe.get("conclusion")))


# ──────────────────────────────────────────────────────────────────────────
# MOTOR DE REFORMULACIÓN POR ESTILOS
# ──────────────────────────────────────────────────────────────────────────

_NOMBRE_A_CLAVE = {"TÉCNICA": "tecnica", "HALLAZGOS": "hallazgos", "CONCLUSIÓN": "conclusion"}


def _prompt_reformulacion_seccion(seccion_nombre: str, seccion_texto: str, estilo_id: str) -> str:
    estilo = ESTILOS_REDACCION[estilo_id]
    return f"""Reescribe exclusivamente la sección {seccion_nombre} de un informe radiológico
siguiendo este estilo:

ESTILO OBJETIVO — {estilo['nombre']}
{estilo['instruccion']}

TEXTO ORIGINAL:
{seccion_texto}

REGLAS NO NEGOCIABLES:
- No agregues, quites ni cambies ningún hallazgo, medida, lateralidad o clasificación.
- Todo dato numérico, categoría (BI-RADS/PI-RADS/TNM/etc.) y lateralidad debe reaparecer idéntico.
- Cambia únicamente: estructura de oración, longitud, conectores, orden de exposición, registro léxico.
- Usa "osteoartrosis" (nunca "osteoartritis") y "desgarro" (nunca "ruptura"/"rasgadura").
- Devuelve SOLO el texto reescrito de la sección, sin encabezados, comillas ni comentarios.

Antes de responder, verifica mentalmente que cada dato clínico del original sigue presente."""


def reformular_seccion(api_key: str, seccion_nombre: str, seccion_texto: str, estilo_id: str,
                        modelo: str = MODELO_DEFECTO) -> str:
    """Reescribe UNA sola sección con el estilo elegido. Llamada síncrona (no streaming):
    las secciones son cortas y el usuario espera un resultado inmediato para comparar."""
    if not seccion_texto.strip():
        return seccion_texto
    cliente = obtener_cliente(api_key)
    respuesta = cliente.chat.completions.create(
        model=modelo,
        messages=[
            {"role": "system", "content": "Eres un editor experto de informes radiológicos en español."},
            {"role": "user", "content": _prompt_reformulacion_seccion(seccion_nombre, seccion_texto, estilo_id)},
        ],
        temperature=0.4,
    )
    return aplicar_terminologia(respuesta.choices[0].message.content.strip())


def _prompt_reformulacion_completa(informe_texto: str, estilo_id: str) -> str:
    estilo = ESTILOS_REDACCION[estilo_id]
    return f"""Reescribe el siguiente informe radiológico COMPLETO siguiendo este estilo:

ESTILO OBJETIVO — {estilo['nombre']}
{estilo['instruccion']}

INFORME ORIGINAL:
{informe_texto}

REGLAS NO NEGOCIABLES:
- Conserva exactamente las tres secciones (TÉCNICA, HALLAZGOS, CONCLUSIÓN) como encabezados
  en mayúsculas, cada una en su propia línea.
- No agregues, quites ni cambies ningún hallazgo, medida, lateralidad o clasificación.
- Todo dato numérico, categoría y lateralidad debe reaparecer idéntico al original.
- Cambia únicamente estructura, longitud, conectores y registro léxico — nunca el contenido clínico.
- Usa "osteoartrosis" (nunca "osteoartritis") y "desgarro" (nunca "ruptura"/"rasgadura").
- Debe leerse como si un radiólogo distinto, con ese estilo particular, hubiera redactado el
  mismo caso — mismo diagnóstico, distinta voz."""


def reformular_informe_completo(api_key: str, informe: dict, estilo_id: str,
                                 modelo: str = MODELO_DEFECTO) -> dict:
    """Reescribe TODO el informe con un estilo, preservando la estructura de tres secciones."""
    cliente = obtener_cliente(api_key)
    texto_original = reconstruir_informe(informe)
    respuesta = cliente.chat.completions.create(
        model=modelo,
        messages=[
            {"role": "system", "content": "Eres un editor experto de informes radiológicos en español."},
            {"role": "user", "content": _prompt_reformulacion_completa(texto_original, estilo_id)},
        ],
        temperature=0.4,
    )
    return parsear_informe(respuesta.choices[0].message.content.strip())
