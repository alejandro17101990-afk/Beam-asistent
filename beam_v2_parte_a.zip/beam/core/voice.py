"""
core/voice.py — Dictado por voz 100% en el navegador.

Usa la Web Speech API nativa de Chrome/Edge (webkitSpeechRecognition).
No requiere ningún paquete de Python ni API key: el reconocimiento corre
del lado del cliente y el texto se escribe en tiempo real en el textarea
de captura.

Nota de implementación: para escribir en el textarea correcto, el script
busca el contenedor de Streamlit cuyo texto visible incluye la etiqueta
del campo (`etiqueta_objetivo`). Es un mecanismo no oficial (manipula el
DOM del documento padre) — funciona hoy con Streamlit >=1.28, pero podría
requerir ajuste si Streamlit cambia su estructura interna en el futuro.
"""

import streamlit.components.v1 as components


def widget_dictado_voz(color_acento: str, etiqueta_objetivo: str, height: int = 56):
    html_code = f"""
    <div style="display:flex;align-items:center;gap:10px;font-family:sans-serif;">
      <button id="beam-mic-btn" title="Dictar" style="
          width:38px;height:38px;border-radius:50%;border:none;cursor:pointer;
          background:{color_acento};display:flex;align-items:center;justify-content:center;
          flex-shrink:0;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="#0B0C0E">
          <path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v5a3 3 0 0 0 3 3z"/>
          <path d="M19 11a1 1 0 1 0-2 0 5 5 0 0 1-10 0 1 1 0 1 0-2 0 7 7 0 0 0 6 6.92V21a1 1 0 1 0 2 0v-3.08A7 7 0 0 0 19 11z"/>
        </svg>
      </button>
      <span id="beam-mic-estado" style="font-size:.8rem;color:#8B8D93;">Dictar hallazgos</span>
    </div>
    <style>
      @keyframes beam-pulse {{
        0%   {{ box-shadow: 0 0 0 0 {color_acento}80; }}
        70%  {{ box-shadow: 0 0 0 12px {color_acento}00; }}
        100% {{ box-shadow: 0 0 0 0 {color_acento}00; }}
      }}
      #beam-mic-btn.escuchando {{ animation: beam-pulse 1.3s infinite; }}
    </style>
    <script>
    (function() {{
      const btn = document.getElementById('beam-mic-btn');
      const estado = document.getElementById('beam-mic-estado');
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const ETIQUETA = {etiqueta_objetivo!r};

      if (!SpeechRecognition) {{
        estado.textContent = 'Dictado no soportado (usa Chrome o Edge)';
        btn.disabled = true; btn.style.opacity = 0.4;
        return;
      }}

      function encontrarTextarea() {{
        const doc = window.parent.document;
        const contenedores = doc.querySelectorAll('[data-testid="stTextArea"]');
        for (const c of contenedores) {{
          if (c.innerText.includes(ETIQUETA)) return c.querySelector('textarea');
        }}
        return null;
      }}

      function escribir(texto) {{
        const ta = encontrarTextarea();
        if (!ta) return;
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ta, texto);
        ta.dispatchEvent(new Event('input', {{ bubbles: true }}));
      }}

      const recog = new SpeechRecognition();
      recog.lang = 'es-MX';
      recog.continuous = true;
      recog.interimResults = true;

      let escuchando = false, detenidoManual = false, base = '', finalAcum = '';

      btn.addEventListener('click', function() {{
        escuchando = !escuchando;
        if (escuchando) {{
          detenidoManual = false;
          const ta = encontrarTextarea();
          base = ta ? ta.value : '';
          finalAcum = '';
          recog.start();
          btn.classList.add('escuchando');
          estado.textContent = 'Escuchando…';
        }} else {{
          detenidoManual = true;
          recog.stop();
          btn.classList.remove('escuchando');
          estado.textContent = 'Dictar hallazgos';
        }}
      }});

      recog.onresult = function(evento) {{
        let interino = '';
        for (let i = evento.resultIndex; i < evento.results.length; i++) {{
          const t = evento.results[i][0].transcript;
          if (evento.results[i].isFinal) finalAcum += t + ' ';
          else interino += t;
        }}
        const separador = base && !base.endsWith(' ') && !base.endsWith('\\n') ? ' ' : '';
        escribir((base + separador + finalAcum + interino).trim());
      }};
      recog.onerror = function(e) {{ estado.textContent = 'Error: ' + e.error; }};
      recog.onend = function() {{ if (escuchando && !detenidoManual) recog.start(); }};
    }})();
    </script>
    """
    components.html(html_code, height=height)
