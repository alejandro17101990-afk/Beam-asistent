"""
core/state.py — Estado de sesión de BEAM.

El informe vive como OBJETO ({tecnica, hallazgos, conclusion}), no como el
último mensaje de un chat. Eso es lo que permite editar/reformular cada
sección de forma independiente.
"""

import os
import streamlit as st


def init_estado():
    st.session_state.setdefault("deepseek_api_key", os.environ.get("DEEPSEEK_API_KEY", ""))
    st.session_state.setdefault("dictado_actual", "")
    st.session_state.setdefault("informe", {"tecnica": "", "hallazgos": "", "conclusion": ""})
    st.session_state.setdefault("generando", False)
    st.session_state.setdefault("estilo_ultimo_aplicado", {})  # {"hallazgos": "clinico", ...}


def informe_esta_vacio() -> bool:
    inf = st.session_state.informe
    return not any((inf.get("tecnica"), inf.get("hallazgos"), inf.get("conclusion")))


def limpiar_para_nuevo_estudio():
    st.session_state.dictado_actual = ""
    st.session_state.informe = {"tecnica": "", "hallazgos": "", "conclusion": ""}
    st.session_state.estilo_ultimo_aplicado = {}
