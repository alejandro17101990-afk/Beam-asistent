"""
core/config.py — Configuración central de BEAM 2.0.

Aquí viven las constantes que el resto de la app consume: paleta visual,
modelo por defecto, reglas terminológicas, el prompt clínico base y el
motor de estilos de reformulación. Nada de lógica de UI ni de red aquí:
este módulo es puro dato/configuración para que sea trivial de editar
sin tocar el resto del código.
"""

# ──────────────────────────────────────────────────────────────────────────
# PROVEEDOR / MODELO
# ──────────────────────────────────────────────────────────────────────────

DEEPSEEK_BASE_URL = "https://api.deepseek.com"
MODELO_DEFECTO = "deepseek-chat"
MODELOS_DEEPSEEK = {
    "deepseek-chat": "DeepSeek Chat (V3) — rápido, uso diario",
    "deepseek-reasoner": "DeepSeek Reasoner (R1) — casos complejos",
}

# ──────────────────────────────────────────────────────────────────────────
# PALETA VISUAL — "Grafito clínico"
# Neutros + un único acento discreto (azul acero). Nada de amarillos ni
# colores saturados: la referencia es Linear/Arc/Claude, no un dashboard.
# ──────────────────────────────────────────────────────────────────────────

PALETA = {
    "bg": "#0B0C0E",           # negro grafito, fondo principal
    "surface": "#141518",       # superficie de tarjetas/paneles
    "surface_alt": "#1B1C20",   # superficie elevada (hover, inputs activos)
    "border": "#26272B",        # bordes sutiles
    "text": "#EDEDEF",          # texto principal
    "muted": "#8B8D93",         # texto secundario / etiquetas
    "accent": "#5B8AA0",        # azul acero — único acento del sistema
    "accent_soft": "#5B8AA026", # acento con transparencia, para hovers/focus
    "success": "#5FA88A",       # verde apagado, solo para confirmaciones
    "danger": "#C97066",        # rojo apagado, solo para errores
}

FUENTE_UI = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"

# ──────────────────────────────────────────────────────────────────────────
# TERMINOLOGÍA CLÍNICA OBLIGATORIA
# ──────────────────────────────────────────────────────────────────────────

TERMINOLOGIA_CORRECTA = {
    "osteoartritis": "osteoartrosis",
    "ruptura": "desgarro",
    "rasgadura": "desgarro",
}

SECCIONES = ["TÉCNICA", "HALLAZGOS", "CONCLUSIÓN"]

# ──────────────────────────────────────────────────────────────────────────
# PROMPT CLÍNICO BASE
# ──────────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT_BASE = """Eres BEAM, un radiólogo experto redactando informes para un contexto
clínico mexicano. No eres un chatbot: eres el motor de redacción de un workspace de informes.
Cuando recibas hallazgos dictados o escritos por el radiólogo, generas directamente el informe
completo, sin preámbulos, sin confirmaciones, sin explicaciones adicionales — solo el informe.

Usa exclusivamente estas tres secciones, en mayúsculas como encabezado en su propia línea,
en prosa narrativa continua (nunca listas ni fragmentos telegráficos):

TÉCNICA
HALLAZGOS
CONCLUSIÓN

NIVEL DE DETALLE Y CRITERIO CLÍNICO:
- Redacta como lo haría un radiólogo experto (nivel fellow), no como una transcripción literal
  de lo dictado.
- El radiólogo normalmente solo dictará los hallazgos POSITIVOS o relevantes. Completa tú, de
  forma sistemática, la descripción del resto de estructuras evaluadas de rutina en ese tipo de
  estudio (revisión por sistemas / "negativa pertinente"), describiéndolas como normales, EXCEPTO
  cuando el dictado indique lo contrario o la técnica no permita evaluarlas.
- NUNCA inventes hallazgos PATOLÓGICOS no mencionados o claramente implícitos. La inferencia
  permitida es únicamente hacia la normalidad de estructuras no mencionadas explícitamente.
- CONCLUSIÓN debe ser concisa, limitada a lo clínicamente relevante, priorizada, con lenguaje
  de cierre diagnóstico apropiado (correlación clínica, seguimiento, estudios adicionales).

TERMINOLOGÍA ESTRICTA (aplica siempre):
- Usa "osteoartrosis", nunca "osteoartritis".
- Usa "desgarro", nunca "ruptura" o "rasgadura" (tendón/menisco).
- Si el caso involucra sistemas de clasificación (BI-RADS, PI-RADS, TI-RADS, LI-RADS,
  Kellgren-Lawrence, Pfirrmann, Stoller, ICRS, Fleischner, Spetzler-Martin, TOAST, AAST),
  inclúyelos correctamente en CONCLUSIÓN con el grado/categoría correspondiente.

Responde siempre en español, y responde ÚNICAMENTE con el informe (TÉCNICA/HALLAZGOS/CONCLUSIÓN),
sin texto antes ni después.
"""

# ──────────────────────────────────────────────────────────────────────────
# MOTOR DE ESTILOS DE REFORMULACIÓN
# Cada estilo es una restricción ESTRUCTURAL verificable, no un adjetivo
# vago — por eso los resultados suenan realmente distintos entre sí.
# ──────────────────────────────────────────────────────────────────────────

ESTILOS_REDACCION = {
    "clinico": {
        "nombre": "Clínico directo",
        "descripcion": "Oraciones cortas, datos medibles por delante.",
        "instruccion": (
            "Oraciones cortas (máximo ~20 palabras), voz activa cuando sea posible, cero "
            "adjetivos ornamentales, prioriza datos medibles sobre descripciones narrativas."
        ),
    },
    "academico": {
        "nombre": "Académico",
        "descripcion": "Registro de discusión de caso en sesión clínica.",
        "instruccion": (
            "Oraciones compuestas con conectores subordinantes (dado que, en tanto que, lo cual "
            "sugiere), terminología completa sin abreviar, tono de discusión de caso en sesión "
            "clínica o ateneo."
        ),
    },
    "conciso": {
        "nombre": "Ultra conciso",
        "descripcion": "Mínima extensión posible sin perder datos.",
        "instruccion": (
            "Reduce cada oración a su núcleo informativo. Elimina toda redundancia y frase de "
            "relleno. Objetivo: no más del 60% de la longitud original en caracteres, sin perder "
            "ni un solo dato clínico."
        ),
    },
    "elegante": {
        "nombre": "Elegante",
        "descripcion": "Fluido, con variación de estructura entre oraciones.",
        "instruccion": (
            "Varía la longitud y estructura de las oraciones para evitar monotonía, usa "
            "transiciones fluidas entre ideas, mantiene precisión clínica sin sonar telegráfico "
            "ni sobrecargado."
        ),
    },
    "rsna": {
        "nombre": "Estilo RSNA (Radiology)",
        "descripcion": "Objetivo e impersonal, secuencia anatómica sistemática.",
        "instruccion": (
            "Registro de journal RSNA: objetivo, impersonal, con secuencia anatómica sistemática "
            "(de superior a inferior o de proximal a distal), sin lenguaje coloquial."
        ),
    },
    "essr": {
        "nombre": "Estilo ESSR",
        "descripcion": "Preciso en grados/clasificaciones musculoesqueléticas.",
        "instruccion": (
            "Registro europeo musculoesquelético: preciso en grados y clasificaciones (Goutallier, "
            "ICRS, Pfirrmann, etc.), frases breves y directas, sin narrativa innecesaria."
        ),
    },
    "ajr": {
        "nombre": "Estilo AJR",
        "descripcion": "Contextualiza antes de describir, cierra con implicancia clínica.",
        "instruccion": (
            "Tono editorial de caso ilustrativo: contextualiza brevemente el hallazgo antes de "
            "describirlo en detalle, y cierra con su implicancia clínica explícita."
        ),
    },
    "profesor": {
        "nombre": "Profesor de alta especialidad",
        "descripcion": "Enseña el razonamiento diagnóstico sin extenderse.",
        "instruccion": (
            "Redacta como si enseñaras el caso a un residente: menciona brevemente el "
            "razonamiento diagnóstico detrás del hallazgo principal (por qué esa impresión y no "
            "otra), sin extenderte más de una oración adicional por hallazgo relevante."
        ),
    },
}

ORDEN_ESTILOS = ["clinico", "academico", "conciso", "elegante", "rsna", "essr", "ajr", "profesor"]
