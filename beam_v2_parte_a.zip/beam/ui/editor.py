"""
ui/editor.py — El workspace de redacción. Aquí vive el "informe como
protagonista": tres secciones editables, cada una con su propio motor de
reformulación por estilo, más una barra de captura compacta arriba (no un
hilo de chat).
"""

import json

import streamlit as st
import streamlit.components.v1 as components

from core import llm, state
from core.config import PALETA, ESTILOS_REDACCION, ORDEN_ESTILOS
from core.voice import widget_dictado_voz

NOMBRE_SECCION = {"tecnica": "TÉCNICA", "hallazgos": "HALLAZGOS", "conclusion": "CONCLUSIÓN"}
ETIQUETA_CAPTURA = "Dictado o hallazgos"


# ──────────────────────────────────────────────────────────────────────────
# COPIAR AL PORTAPAPELES (JS puro, sin dependencias)
# ──────────────────────────────────────────────────────────────────────────

def _boton_copiar(texto: str, etiqueta: str, key: str):
    texto_js = json.dumps(texto or "")
    html = f"""
    <button id="beam-copy-{key}" style="
        width:100%; background:{PALETA['surface_alt']}; color:{PALETA['text']};
        border:1px solid {PALETA['border']}; border-radius:8px;
        font-size:0.8rem; font-weight:500; padding:7px 10px; cursor:pointer;
        font-family:sans-serif;">{etiqueta}</button>
    <script>
    document.getElementById('beam-copy-{key}').addEventListener('click', function() {{
        navigator.clipboard.writeText({texto_js});
        const el = this;
        const original = el.innerText;
        el.innerText = '✓ Copiado';
        setTimeout(() => {{ el.innerText = original; }}, 1400);
    }});
    </script>
    """
    components.html(html, height=42)


# ──────────────────────────────────────────────────────────────────────────
# BARRA DE CAPTURA (dictado o texto libre)
# ──────────────────────────────────────────────────────────────────────────

def renderizar_barra_captura() -> bool:
    st.markdown('<div class="beam-caja-captura">', unsafe_allow_html=True)

    col_txt, col_mic = st.columns([11, 1])
    with col_txt:
        st.session_state.dictado_actual = st.text_area(
            ETIQUETA_CAPTURA,
            value=st.session_state.dictado_actual,
            height=88,
            placeholder="Dicta o escribe los hallazgos del estudio…",
            key="dictado_actual_widget",
        )
    with col_mic:
        st.markdown("<div style='height:22px;'></div>", unsafe_allow_html=True)
        widget_dictado_voz(PALETA["accent"], etiqueta_objetivo=ETIQUETA_CAPTURA, height=60)

    col_btn, col_hint = st.columns([2, 6])
    with col_btn:
        generar = st.button(
            "Generar informe", type="primary", use_container_width=True,
            disabled=not st.session_state.dictado_actual.strip(),
        )
    with col_hint:
        st.markdown(
            '<div style="height:38px;display:flex;align-items:center;">'
            '<span style="font-size:.78rem;color:var(--muted);">'
            'La IA infiere estructuras normales no dictadas — nunca inventa patología.'
            '</span></div>',
            unsafe_allow_html=True,
        )

    st.markdown("</div>", unsafe_allow_html=True)
    return generar


def generar_y_mostrar(api_key: str, modelo: str):
    """Genera el informe en streaming (vista previa de texto plano) y luego lo
    parsea a las tres secciones editables. Nota de diseño: el streaming se
    muestra como documento único mientras se redacta (feedback inmediato de
    que algo está pasando); en cuanto termina, se reparte en los tres campos
    editables independientes — ese es el momento en que el documento se
    vuelve "tuyo" para pulir."""
    contenedor = st.empty()
    acumulado = ""
    try:
        for fragmento in llm.generar_informe_stream(api_key, st.session_state.dictado_actual, modelo=modelo):
            acumulado += fragmento
            contenedor.markdown(
                f'<div class="beam-tarjeta" style="white-space:pre-wrap;font-size:0.92rem;'
                f'line-height:1.6;">{acumulado}▍</div>',
                unsafe_allow_html=True,
            )
        st.session_state.informe = llm.parsear_informe(acumulado)
        contenedor.empty()
        st.rerun()
    except Exception as e:
        contenedor.empty()
        st.error(f"Error al generar el informe: {e}")


# ──────────────────────────────────────────────────────────────────────────
# SECCIONES EDITABLES + REFORMULACIÓN POR ESTILO
# ──────────────────────────────────────────────────────────────────────────

def _fila_reformulacion(clave: str, visible: str, api_key: str, modelo: str):
    col_sel, col_btn, col_copy = st.columns([5, 2, 2])

    with col_sel:
        estilo_id = st.selectbox(
            f"Estilo — {visible}",
            options=ORDEN_ESTILOS,
            format_func=lambda k: f"{ESTILOS_REDACCION[k]['nombre']} · {ESTILOS_REDACCION[k]['descripcion']}",
            key=f"estilo_{clave}",
            label_visibility="collapsed",
        )
    with col_btn:
        aplicar = st.button("Reformular", key=f"reformular_{clave}", use_container_width=True)
    with col_copy:
        _boton_copiar(st.session_state.informe.get(clave, ""), "Copiar sección", key=clave)

    if aplicar:
        if not api_key:
            st.error("Configura tu API key de DeepSeek en la barra lateral.")
            return
        with st.spinner(f"Reescribiendo {visible.lower()} — estilo {ESTILOS_REDACCION[estilo_id]['nombre']}…"):
            try:
                nuevo_texto = llm.reformular_seccion(
                    api_key, NOMBRE_SECCION[clave], st.session_state.informe[clave], estilo_id, modelo=modelo,
                )
                st.session_state.informe[clave] = nuevo_texto
                st.session_state.estilo_ultimo_aplicado[clave] = estilo_id
                st.rerun()
            except Exception as e:
                st.error(f"No se pudo reformular: {e}")


def renderizar_editor(api_key: str, modelo: str):
    etiquetas = {"tecnica": "Técnica", "hallazgos": "Hallazgos", "conclusion": "Conclusión"}
    alturas = {"tecnica": 90, "hallazgos": 220, "conclusion": 130}

    for clave, visible in etiquetas.items():
        st.markdown('<div class="beam-tarjeta">', unsafe_allow_html=True)
        texto_actual = st.text_area(
            visible,
            value=st.session_state.informe.get(clave, ""),
            height=alturas[clave],
            key=f"texto_{clave}",
        )
        st.session_state.informe[clave] = texto_actual
        _fila_reformulacion(clave, visible, api_key, modelo)
        st.markdown("</div>", unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────────
# BARRA INFERIOR — informe completo
# ──────────────────────────────────────────────────────────────────────────

def renderizar_barra_inferior(api_key: str, modelo: str):
    st.markdown('<div class="beam-tarjeta">', unsafe_allow_html=True)
    col1, col2, col3, col4 = st.columns([4, 2, 2, 2])

    with col1:
        estilo_global = st.selectbox(
            "Estilo — informe completo",
            options=ORDEN_ESTILOS,
            format_func=lambda k: f"{ESTILOS_REDACCION[k]['nombre']} · {ESTILOS_REDACCION[k]['descripcion']}",
            key="estilo_global",
            label_visibility="collapsed",
        )
    with col2:
        aplicar_global = st.button("Reformular todo", use_container_width=True)
    with col3:
        _boton_copiar(llm.reconstruir_informe(st.session_state.informe), "Copiar informe", key="informe_completo")
    with col4:
        nuevo_estudio = st.button("＋ Nuevo estudio", use_container_width=True)

    st.markdown("</div>", unsafe_allow_html=True)

    if aplicar_global:
        if not api_key:
            st.error("Configura tu API key de DeepSeek en la barra lateral.")
        else:
            with st.spinner(f"Reescribiendo el informe completo — estilo {ESTILOS_REDACCION[estilo_global]['nombre']}…"):
                try:
                    st.session_state.informe = llm.reformular_informe_completo(
                        api_key, st.session_state.informe, estilo_global, modelo=modelo,
                    )
                    st.rerun()
                except Exception as e:
                    st.error(f"No se pudo reformular el informe: {e}")

    if nuevo_estudio:
        state.limpiar_para_nuevo_estudio()
        st.rerun()
