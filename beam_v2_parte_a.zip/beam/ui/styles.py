"""
ui/styles.py — Identidad visual de BEAM 2.0.

Un único acento discreto (azul acero), neutros para todo lo demás,
tipografía Inter, espaciado generoso. El objetivo es que el informe
se sienta como el protagonista y la IA quede en segundo plano.
"""

import streamlit as st
from core.config import PALETA, FUENTE_UI

GOOGLE_FONTS_IMPORT = (
    "@import url('https://fonts.googleapis.com/css2?"
    "family=Inter:wght@400;500;600;700&display=swap');"
)


def inyectar_estilo():
    p = PALETA
    st.markdown(
        f"""
        <style>
        {GOOGLE_FONTS_IMPORT}

        :root {{
            --bg: {p['bg']}; --surface: {p['surface']}; --surface-alt: {p['surface_alt']};
            --border: {p['border']}; --text: {p['text']}; --muted: {p['muted']};
            --accent: {p['accent']}; --accent-soft: {p['accent_soft']};
        }}

        .stApp {{ background-color: var(--bg); color: var(--text); font-family: {FUENTE_UI}; }}

        section[data-testid="stSidebar"] {{
            background-color: var(--surface); border-right: 1px solid var(--border);
        }}

        /* Encabezados de sección del informe — mayúsculas espaciadas, estilo editorial */
        .beam-seccion-titulo {{
            font-size: 0.72rem; font-weight: 600; letter-spacing: 0.12em;
            color: var(--muted); text-transform: uppercase; margin: 0 0 6px 2px;
        }}

        .beam-header {{
            display: flex; align-items: baseline; justify-content: space-between;
            margin-bottom: 4px;
        }}

        .beam-titulo-app {{
            font-size: 1.05rem; font-weight: 600; color: var(--text); letter-spacing: -0.01em;
        }}
        .beam-subtitulo-app {{
            font-size: 0.78rem; color: var(--muted);
        }}

        /* Inputs y textareas — bordes finos, foco discreto con el acento */
        textarea, input[type="text"], input[type="password"] {{
            background-color: var(--surface) !important;
            color: var(--text) !important;
            border: 1px solid var(--border) !important;
            border-radius: 10px !important;
            font-family: {FUENTE_UI} !important;
        }}
        textarea:focus, input:focus {{
            border-color: var(--accent) !important;
            box-shadow: 0 0 0 3px var(--accent-soft) !important;
        }}

        [data-testid="stTextArea"] textarea {{
            font-size: 0.93rem; line-height: 1.65;
        }}

        /* Etiquetas de campos como encabezados editoriales (mayúsculas, espaciadas) */
        [data-testid="stWidgetLabel"] p {{
            font-size: 0.72rem !important; font-weight: 600 !important;
            letter-spacing: 0.1em !important; text-transform: uppercase !important;
            color: var(--muted) !important;
        }}

        /* Botones — neutros por defecto, el acento se reserva para la acción primaria */
        div.stButton > button {{
            background-color: var(--surface-alt);
            color: var(--text);
            border: 1px solid var(--border);
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.84rem;
            padding: 0.4rem 0.9rem;
        }}
        div.stButton > button:hover {{
            border-color: var(--accent);
            color: var(--accent);
        }}
        div.stButton > button[kind="primary"] {{
            background-color: var(--accent);
            color: #0B0C0E;
            border: none;
            font-weight: 600;
        }}
        div.stButton > button[kind="primary"]:hover {{
            filter: brightness(1.08);
            color: #0B0C0E;
        }}

        div[data-testid="stSelectbox"] > div {{
            background-color: var(--surface); border-radius: 8px;
        }}

        hr {{ border-color: var(--border) !important; }}

        .beam-tarjeta {{
            background-color: var(--surface);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 18px 20px;
            margin-bottom: 14px;
        }}

        .beam-caja-captura {{
            background-color: var(--surface);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 14px 16px 10px 16px;
            margin-bottom: 22px;
        }}

        .beam-badge {{
            display: inline-block; font-size: 0.68rem; font-weight: 600;
            letter-spacing: 0.05em; text-transform: uppercase;
            color: var(--accent); background: var(--accent-soft);
            border-radius: 6px; padding: 2px 8px; margin-left: 8px;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )
