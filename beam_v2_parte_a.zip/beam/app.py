"""
app.py — BEAM 2.0, Parte A: workspace de tres secciones + motor de
reformulación por estilos.

Ejecutar:
    streamlit run app.py

Requiere una API key de DeepSeek (https://platform.deepseek.com), que se
configura una sola vez desde "Configuración" en la barra lateral.
"""

import streamlit as st

from core import state
from core.config import MODELOS_DEEPSEEK
from ui.styles import inyectar_estilo
from ui import editor

st.set_page_config(
    page_title="BEAM · Workspace radiológico",
    page_icon="◆",
    layout="wide",
    initial_sidebar_state="expanded",
)


def main():
    state.init_estado()
    inyectar_estilo()

    with st.sidebar:
        st.markdown('<div class="beam-titulo-app">BEAM</div>', unsafe_allow_html=True)
        st.markdown(
            '<div class="beam-subtitulo-app">Workspace de informes radiológicos</div>',
            unsafe_allow_html=True,
        )
        st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)

        with st.expander("Configuración", expanded=not st.session_state.deepseek_api_key):
            st.session_state.deepseek_api_key = st.text_input(
                "DeepSeek API key",
                value=st.session_state.deepseek_api_key,
                type="password",
                placeholder="sk-...",
            )
            modelo = st.selectbox(
                "Modelo",
                list(MODELOS_DEEPSEEK.keys()),
                format_func=lambda m: MODELOS_DEEPSEEK[m],
                index=0,
            )

    st.markdown(
        '<div class="beam-header">'
        '<span class="beam-titulo-app">Nuevo estudio<span class="beam-badge">BEAM 2.0</span></span>'
        "</div>",
        unsafe_allow_html=True,
    )

    generar = editor.renderizar_barra_captura()
    if generar:
        if not st.session_state.deepseek_api_key:
            st.error("Configura tu API key de DeepSeek en la barra lateral.")
        else:
            editor.generar_y_mostrar(st.session_state.deepseek_api_key, modelo)

    if not state.informe_esta_vacio():
        editor.renderizar_editor(st.session_state.deepseek_api_key, modelo)
        editor.renderizar_barra_inferior(st.session_state.deepseek_api_key, modelo)
    else:
        st.markdown(
            '<p style="color:var(--muted);font-size:.85rem;">'
            "El informe aparecerá aquí, en secciones editables, en cuanto lo generes."
            "</p>",
            unsafe_allow_html=True,
        )


if __name__ == "__main__":
    main()
